package com.example.fooddonationapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StatusDetailAdapter  extends RecyclerView.Adapter<StatusDetailAdapter.ViewHolder> {


    // creating variables for our ArrayList and context
    private ArrayList<StatusDetails> statusArrayList;
    private Context context;

    // creating constructor for our adapter class
    public StatusDetailAdapter(ArrayList<StatusDetails> statusArrayList, Context context) {
        this.statusArrayList = statusArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public StatusDetailAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // passing our layout file for displaying our card item
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_view_status, parent, false));
    }@Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // setting data to our text views from our modal class.
        StatusDetails status = statusArrayList.get(position);
        holder.ngoName.setText(status.getNgoName());
        holder.statusPacket.setText(status.getNoPackets());
        holder.statusUpdate.setText(status.getStatus());

    }

    @Override
    public int getItemCount() {
        // returning the size of our array list.
        return statusArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our text views.
        private final TextView ngoName;
        private final TextView statusPacket;
        private final TextView statusUpdate;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views.
            ngoName= itemView.findViewById(R.id.NgoName);
            statusPacket = itemView.findViewById(R.id.Food_Packet);
            statusUpdate = itemView.findViewById(R.id.Food_Status);
        }
    }}


