package com.example.fooddonationapp;

public class StatusDetails {

    private String NgoName, Packets, Status, Uid;

    public StatusDetails() {
        // empty constructor
        // required for Firebase.
    }

    // Constructor for all variables.
    public StatusDetails(String ngoName, String packets,String status,String uid) {
        this.NgoName = ngoName;
        this.Packets = packets;
        this.Status = status;
        this.Uid = Uid;

    }

    // getter methods for all variables.
    public String getNgoName() {
        return NgoName;
    }
    // setter method for all variables.
    public void setNgoName(String ngoName) {
        this.NgoName = ngoName;
    }

    public String getNoPackets() {
        return Packets;
    }

    public void setNoPackets(String packets) {
        this.Packets = packets;
    }

    public String getStatus() { return Status; }

    public void setStatus(String status) { this.Status = status; }

    public String getUid() { return Uid; }

    public void setUid(String uid) { this.Uid = uid; }

}

