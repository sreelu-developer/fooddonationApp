package com.example.fooddonationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DonorContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_contact);
    }
}