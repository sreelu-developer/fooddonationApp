package com.example.fooddonationapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;



public class UpdateStatusActivity extends AppCompatActivity {
    EditText NgoName, Packet, Status;
    Button UpdateBtn;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_status);
        NgoName = findViewById(R.id.NameET);
        UpdateBtn=findViewById(R.id.UpdateBtn);
        Packet = findViewById(R.id.PacketsET);
        Status = findViewById(R.id.StatusET);
        // getting our instance
        // from Firebase Firestore.
        fStore = FirebaseFirestore.getInstance();
        fAuth = FirebaseAuth.getInstance();
        userID = fAuth.getCurrentUser().getUid();
        Log.d("value of x is ", String.valueOf(userID));

        UpdateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ngoName = NgoName.getText().toString().trim();
                String packet = Packet.getText().toString().trim();
                String status = Status.getText().toString().trim();

                String Uid = userID;

                String state = "new";
                if (TextUtils.isEmpty(ngoName)) {
                    NgoName.setError("Ngo Name is Required.");

                    return;
                }

                if (TextUtils.isEmpty(packet)) {
                    Packet.setError("No. of packets is Required.");
                    return;
                }

                if (TextUtils.isEmpty(status)) {
                    Status.setError("Status is required");
                    return;
                }
                // calling method to add data to Firebase Firestore.
                addDataToFirestore(ngoName, packet, status, Uid);


            }

            private void addDataToFirestore(String ngoName, String packet, String state, String ngoid) {

                // creating a collection reference
                // for our Firebase Firetore database.
                CollectionReference dbstatus = fStore.collection("status");

                // adding our data to our courses object class.
                StatusDetails sd = new StatusDetails(ngoName, packet, state, ngoid);

                // below method is use to add data to Firebase Firestore.
                dbstatus.add(sd).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        // after the data addition is successful
                        // we are displaying a success toast message.
                        Toast.makeText(UpdateStatusActivity.this, "Your Request has been Sent", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // this method is called when the data addition process is failed.
                        // displaying a toast message when data addition is failed.
                        Toast.makeText(UpdateStatusActivity.this, "Fail to Sent Request \n" + e, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

    }}


