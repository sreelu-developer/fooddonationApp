package com.example.fooddonationapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DonateDetailAdapter  extends RecyclerView.Adapter<DonateDetailAdapter.ViewHolder> {


    // creating variables for our ArrayList and context
    private ArrayList<DonateDetails> donateArrayList;
    private Context context;

    // creating constructor for our adapter class
    public DonateDetailAdapter(ArrayList<DonateDetails> donateArrayList, Context context) {
        this.donateArrayList = donateArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public DonateDetailAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // passing our layout file for displaying our card item
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_donor_request, parent, false));
    }@Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // setting data to our text views from our modal class.
        DonateDetails donations = donateArrayList.get(position);
        holder.ngoName.setText(donations.getNgoName());
        holder.donatePacket.setText(donations.getNoPackets());
        holder.donateDate.setText(donations.getDatelimit());
        holder.donateDuration.setText(donations.getTimeDuration());
        holder.donateAddress.setText(donations.getAddress());
        holder.locatebtn.setOnClickListener((new View.OnClickListener() {


            Uri gmmIntentUri = Uri.parse("geo:0,0?q="+donations.getAddress());
            public void onClick(View view) {
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                context.startActivity(mapIntent);
            }
        }));

          holder.contactbtn.setOnClickListener((new View.OnClickListener() {
              @Override
              public void onClick(View view) {
                  Intent intent = new Intent(context, DonorContactActivity.class);
                  intent.putExtra("key1",donations.getUid());
                  context.startActivity(intent);
              }
          }));







    }



    @Override
    public int getItemCount() {
        // returning the size of our array list.
        return donateArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        // creating variables for our text views.
        private final TextView ngoName;
        private final TextView donatePacket;
        private final TextView donateDate;
        private final TextView donateDuration;
        private final TextView donateAddress;


        Button locatebtn,contactbtn;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing our text views.
            ngoName= itemView.findViewById(R.id.NgoName3);
            donatePacket = itemView.findViewById(R.id.FoodQuantity);
            donateDate=itemView.findViewById(R.id.CollectionDate);
            donateDuration = itemView.findViewById(R.id.CollectionTime);
            donateAddress=itemView.findViewById(R.id.PickPoint);
            locatebtn=itemView.findViewById(R.id.locatebtn);
            contactbtn= itemView.findViewById(R.id.contactbtn);

            itemView.findViewById(R.id.statusbtn).setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, UpdateStatusActivity.class);
                    context.startActivity(intent);
                }
            }));
            itemView.findViewById(R.id.acceptbtn).setOnClickListener((new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    view.setClickable(false);
                    view.setEnabled(false);
                }
            }));


    }
}}

