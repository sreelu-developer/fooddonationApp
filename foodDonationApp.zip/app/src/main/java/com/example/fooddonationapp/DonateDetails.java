package com.example.fooddonationapp;

public class DonateDetails {

    private String NgoName , NoPackets, TimeDuration, Datelimit, Address, Uid;

    public DonateDetails() {
        // empty constructor
        // required for Firebase.
    }

    // Constructor for all variables.
    public DonateDetails(String ngoName, String noPackets, String timeDuration,String datelimit,String address,String Uid) {
        this.NgoName = ngoName;
        this.NoPackets = noPackets;
        this.TimeDuration = timeDuration;
        this.Uid = Uid;
        this.Address = address;
        this.Datelimit =datelimit;
    }

    // getter methods for all variables.
    public String getNgoName() {
        return NgoName;
    }
    // setter method for all variables.
    public void setNgoName(String ngoName) {
        this.NgoName = ngoName;
    }

    public String getNoPackets() {
        return NoPackets;
    }

    public void setNoPackets(String noPackets) {
        this.NoPackets = noPackets;
    }

    public String getDatelimit() { return Datelimit; }

    public void setDatelimit(String datelimit) { this.Datelimit = datelimit; }

    public String getTimeDuration() {
        return TimeDuration;
    }

    public void setTimeDuration(String timeDuration) {
        this.TimeDuration = timeDuration;
    }

    public String getAddress() { return Address; }

    public void setAddress(String address) {
        this.Address = address;
    }

    public String getUid() { return Uid; }

    public void setUid(String uid) { this.Uid = uid; }

}
